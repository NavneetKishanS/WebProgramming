# Task 1 - Tic-tac-toe

- [ ] a.
- [ ] b.
- [ ] c.
- [ ] d.
