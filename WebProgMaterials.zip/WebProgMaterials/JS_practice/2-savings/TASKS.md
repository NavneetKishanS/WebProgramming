# Task 2 - Savings

- [ ] a.
- [ ] b.
- [ ] c.
- [ ] d.
