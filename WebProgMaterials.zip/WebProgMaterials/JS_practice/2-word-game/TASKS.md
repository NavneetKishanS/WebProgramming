# Task 2 - Word game

- [ ] a.
- [ ] b.
- [ ] c.
- [ ] d.
- [ ] e.
- [ ] f.
- [ ] g.
- [ ] h.
