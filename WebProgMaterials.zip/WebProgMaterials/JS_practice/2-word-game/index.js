// ========= Utility functions =========
function random(a, b) {
  return Math.floor(Math.random() * (b - a + 1)) + a;
}

// ========= Selected elements =========
const inputGuess = document.querySelector("#inputGuess");
const form = document.querySelector("form");
const tableGuesses = document.querySelector("#guesses");
const divTheWord = document.querySelector("details > div");
const spanError = document.querySelector("#error");
const btnGuess = document.querySelector("form > button");
const divEndOfGame = document.querySelector("#end-of-game");
const btnRestart = document.querySelector("#restart");

// ========= Solution =========
//Task 1
let randomWord = wordList[random(0, random.length)];
divTheWord.innerHTML = randomWord;

//Task2
form.addEventListener('submit', function(event) {
  event.preventDefault(); // Prevent form submission

  // Select text in the text field
  inputGuess.select();

  // Clear the content of the span element
  spanError.textContent = ""; // or spanError.innerHTML = "";

  // Additional actions or logic you want to perform

  // For example:
  // tableGuesses.innerHTML = ""; // Clear table content

  // Optional: You can reset the form if needed
  // form.reset();
});
/*addEventListener.btnGuess('submit',function(){
  inputGuess.innerHTML = "";
})
*/

//Task3
form.addEventListener('submit',function(e){
  if(inputGuess.value.length !== 5){
    spanError.textContent = "The length of the word is not 5!"
  }
})

//Task4
form.addEventListener('submit',function(e){
  if(inputGuess.value.length === 5){
    if(!wordList.includes(inputGuess.value)){
      spanError.textContent = "The word is not considered acceptable!"
    }
  }
})

//Task5
form.addEventListener('submit', function(e) {
  e.preventDefault(); // Prevent form submission

  console.log(countCorrectPlaced(inputGuess.value, randomWord));
/*
  if (inputGuess.value.length === 5) {
    if (!wordList.includes(inputGuess.value)) {
      spanError.textContent = "The word is not considered acceptable!";
    } else {
      spanError.textContent = ""; // Clear error message if the word is acceptable
      console.log(countCorrectPlaced(inputGuess.value, randomWord)); // Log the count to the console
    }
  }*/
});

function countCorrectPlaced(str1, str2) {
  let c = 0;
  for (let i = 0; i < str1.length; i++) {
    if (str1[i] === str2[i]) {
      c++;
    }
  }
  return c;
}

//Task6
form.addEventListener('submit', function(e) {
  e.preventDefault(); // Prevent form submission

  //console.log(countCorrectPlaced(inputGuess.value, randomWord));
  //if(inputGuess.value === randomWord){
    //tableGuesses.appendChild.createelement('td').innertext = randomWord;
  
    const newRow = document.createElement('tr');

    // Create table data cells for word and matches
    const wordCell = document.createElement('td');
    wordCell.innerText = guessedWord;
  
    const matchesCell = document.createElement('td');
    matchesCell.innerText = matches;
  
    // Append cells to the new row
    newRow.appendChild(wordCell);
    newRow.appendChild(matchesCell);
  //}
});