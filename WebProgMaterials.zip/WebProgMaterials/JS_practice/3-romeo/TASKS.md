# Task 3 - Romeo and Juliet 

- [ ] a.
- [ ] b.
- [ ] c.
- [ ] d.
- [ ] e.
- [ ] f.
- [ ] g.
- [ ] h.
