Plugins:
LiveServer
PHP Intelephense

php

$filtered = array_filter($gdata, fn($i) => $i["startHour"] == $hour);
        /*
        $gdata: This is an array that you want to filter.

        fn is an anonymous function!
        fn($i) => $i["startHour"] == $hour: This is an anonymous arrow function (lambda function) used as a callback for array_filter. It takes an element $i from the array and checks if the value of the "startHour" key in that element is equal to the value of the variable $hour.

        array_filter($gdata, fn($i) => $i["startHour"] == $hour): This function call filters the array $gdata by applying the callback function to each element. Only elements for which the callback function returns true are included in the resulting $filtered array.

        So, after this line of code is executed, $filtered will contain only those elements from $gdata where the "startHour" key is equal to the value stored in the variable $hour.
        */


$associativeArray = [
    "name" => "John",
    "age" => 30,
    "city" => "New York"
];

$keys = array_keys($associativeArray);
        /* Returns key -> ["name", "age", "city"]
$keysWithNameJohn = array_keys($associativeArray, "John"); -> 
        /* ["name"]


in_array($brand, $brandArr)
        /* is element in array?

is_numeric($goblins) vs filter_var($goblins, FILTER_VALIDATE_INT)
        /* Different


array_search($needle, $haystack, $strict = false)

            $words = ["apple", "banana", "cherry"];
            $ranks = ["orange", "banana", "apple", "grape"];

            $result = array_search($words[count($words) - 1], $ranks);

            if ($result !== false) {
                echo "Found at index: " . $result;
            } else {
                echo "Not found";
            }



$types = array_unique(array_column($shop, "type"));