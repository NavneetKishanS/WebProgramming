<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    Some Content.
    <?php
        echo "Hello World";
        echo 2+2;
        echo(2+2);
        print 2+2;
        print(2+2);

        $var = 3;
        echo $var;

        echo "\n\n\n\n";


        $t = [0,1,2,3,4,5,6,7,8,9];
        for($i =0;$i<10;$i++){
            print $t[$i]."\n";
        }

        function isEve($n){
            if($n % 2 === 0){
                return TRUE;
            }
            else{
                return FALSE;
            }
        }

        $result = isEve(5);
        echo $result ? "The number is even" : "The number is odd";
        function keepEven($arr){
            $newArr = [];
            foreach($arr as $i)
            {
                if($i % 2 == 0){
                    $newArr[] = $i; // Append the even numbers to the array
                }
            }
            return $newArr; // Don't forget to return the new array
        }
        >
        <form action='1.php' method='GET'>
        a = <input type="number" name="a"><br>
        b = <input type="number" name="b"><br>
        <input type="submit" value="Send">
        </form>
    
</body>
</html>