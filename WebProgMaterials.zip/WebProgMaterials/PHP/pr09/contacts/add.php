<?php
include_once("contactstorage.php");

print_r($_POST);  // $_GET, $_POST

function validate($input, &$data, &$errors) {
  $data = $input;
  return true;
}

$data = [];
$errors = [];
if (count($_POST) > 0) { // if there is incoming data
  if (validate($_POST, $data, $errors)) {
    $cs = new ContactStorage();
    $cs->add($data);
    header("Location: index.php");
    exit();
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  <h1>Contacts</h1>
  <h2>Add new contact</h2>
  <form action="" method="post" novalidate>
    Name: <br>
    <input type="text" name="name" required> <br>
    Emails: <br>
    <input type="email" name="emails[]"> <br>
    <input type="email" name="emails[]"> <br>
    <input type="email" name="emails[]"> <br>
    Phone: <br>
    <input type="tel" name="phone"> <br>
    <button>Save contact</button>
  </form>
</body>
</html>