<?php
// "c:\Users\gyozke\Desktop\2023-24-1\web programming\pr09\contacts\contactstorage.php" 
include_once("contactstorage.php");
$cs = new ContactStorage();

// $normal_array = [
//   0 => 1, 
//   1 => 3, 
//   2 => 5, 
//   3 => 3
// ];
// $associative_array = [
//   "key1"  => "value1",
//   "key2"  => "value2",
//   "key3"  => "value3",
// ];

// $cs->add([
//   "name"    => "Chris Pratt",
//   "emails"  => [
//     "chris@pratt.com"
//   ],
//   "phone"   => "+12345325463524152",
// ]);
// read input
$contacts = $cs->findAll();
// print_r($contacts);
// process data

// write output
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  <h1>Contacts</h1>
  <a href="add.php">Add new contact...</a>
  <table>
    <thead>
      <tr>
        <th>Name</th>
        <th>Emails</th>
        <th>Phone</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($contacts as $c) : ?>
        <tr>
          <td><?= $c["name"] ?></td>
          <td><?= implode(", ", $c["emails"]) ?></td>
          <td><?= $c["phone"] ?></td>
        </tr>
      <?php endforeach ?>
    </tbody>
  </table>
</body>
</html>