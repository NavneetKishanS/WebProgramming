<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php 
    $x = 5;
    echo $x;
    print $x;
    echo "<br> $x";
    echo "<br>";
    if($x == 4){
        echo "x is 4";
    }else{
        echo "x is $x";
    }
    echo "<br>";
    for($i = 0; $i<=10; $i++){
        echo "$i <br>";
    }
    echo "<br>";
    $t = [1,2,3,4];
    for($i =0;$i<count($t);$i++){
        echo $t[$i]."<br>";
        //
    }
    echo "<br>";
    foreach($t as $i){
        echo $i. "<br>";
    }
    echo "<br>";
    $u =[
        'a' => 3,
        'b' => 4
    ];
    echo $u['a'];
    echo $u['b'];
    echo "<br>";

    $zero = 0;
    function isEven($n){
        return ($n % 2 === 0);
    }
    echo isEven(3);
    
    echo isEven(4) ? 'true' : 'false';

    // EXERCISES
    // ARRAY OF NUMBERS
    // 1.) filter the even elements - find array functions :)
    // 2.) calculate the square of each element - find array functions :)
    // 3.) display it as a list (ul - li) - try alternative syntax
    echo "<br>";

    $filtered = [];
    foreach($t as $i)
    {
        if($i % 2 === 0){
            $filtered[] = $i ;
        }
    }

    print_r($filtered);
    echo "<br>";
    print_r(array_filter($filtered,'isEven'));
    echo "<br>";
    print_r(array_map(function($i){
        return $i*$i;
    },$t));
    echo "<br>";
    echo "<ul>";
    foreach($t as $i){
        echo "<li>" . $i;
    }
    echo "</ul>";
    ?>

</body>
</html>