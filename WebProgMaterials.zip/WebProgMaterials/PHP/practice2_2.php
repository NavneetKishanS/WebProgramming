<?php
$errors = [];
$fullname = $_POST['fullname'] ?? '' ;
$email = $_POST['email'] ?? '';
$age = $_POST['age']?? '';
$accept = $_POST['accept']?? '';

if($_POST){
    if(count(explode(' ',$fullname))<2){
        $errors['fullname'] = 'name should be at least 2 words';
    }
    if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        $errors['email'] = 'the email is not valid';
    }
    if(!filter_var($age, FILTER_VALIDATE_INT) === false){
        $errors['age'] = 'the age is not valid. It must be a number';
    }
    if(!filter_var($accept, FILTER_VALIDATE_BOOLEAN)){
        $errors['accept'] = 'Checkbox must be checked';
    }
    if(count($errors) === 0){
        $person = [
            "fullname" => $fullname,
            "email" => $email,
            "age" => intval($age)
        ];
        $data = json_decode(file_get_contents('data.json'),true);
        $data[] = $person;
        file_put_contents('data.json', json_encode($data, JSON_PRETTY_PRINT));
        header("location: list.php");
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <ul>
        <?php foreach($errors as $e){
            echo "<ls> $e </li>";
        }
        ?>
    </ul>
    <form action="practice2_2.php" method="POST">
        Full Name: <input type="text" name ="fullname" value="<?= $fullname ?>">
        <?= $errors['fullname']??''?>  <br>
        Email: <input type="text" name ="email" value="<?= $email ?>">
        <?= $errors['email'] ?? '' ?>  <br>
        Age: <input type="number" name ="age" value="<?= $age ?>">
        <?= $errors['age'] ?? '' ?>  <br>
        Checkbox: <input type="checkbox" name ="accept" value="<?= $accept ?>">
        <?= $accept ? 'checked' : '' ?><br>
        <?= $errors['accept'] ?? '' ?>  <br>
        <button>Send</button>
    </form>
    <?php if ($_POST && count($errors)===0): ?>
        <h1> Congratulations you did it! :) </h1>
    <?php endif; ?>
</body>
</html>