# Task 1: Candies

- [X] a.
- [X] b.
- [X] c.
- [ ] d.
- [ ] e.
- [ ] f.
