<?php

$shop = [
  [ "brand" => "Homemade", "type"  => "Dark chocolate", "price" => 2000 ],
  [ "brand" => "Grandma's", "type"  => "Milk chocolate", "price" => 1500 ],
  [ "brand" => "Worldsweet", "type"  => "Milk chocolate", "price" => 3000 ],
  [ "brand" => "Worldsweet", "type"  => "Dark chocolate", "price" => 4000 ],
  [ "brand" => "Worldsweet", "type"  => "Orange essence", "price" => 4000 ],
  [ "brand" => "Homemade", "type"  => "Milk chocolate", "price" => 1000 ],
  [ "brand" => "Speziale", "type"  => "Apple & Cinnamon", "price" => 1000 ]
];

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="index.css">
  <title>Task 1</title>
</head>
<body>
  <h1>Task 1: Candies</h1>
  <!-- Your solution goes here! -->
<?php
//echo "</tr>";

$uniqType = array_unique(array_column($shop, 'type'));
$uniqBrand = array_unique(array_column($shop, 'brand'));
sort($uniqType);
sort($uniqBrand);
$prices = array_column($shop,'price');
$lowestPrice = min($prices);
$highestPrice = max($prices);
/*
echo "<table><tr><td>";
foreach($uniqType as $i){
  echo "<td>$i</td>";
}
echo  "</tr>";
foreach($uniqBrand as $u){
  echo "<tr><td>$u</tr>";
}
?> 
echo "</table>";
*/
echo "<table><tr><td></td>"; // Empty cell for the top-left corner

// Displaying unique types as headers in the first row

foreach($uniqType as $type){
  echo "<td>$type</td>";
}
echo "</tr>";

// Displaying unique types as headers in the first row
foreach($uniqType as $type){
  echo "<td>$type</td>";
}
echo "</tr>";

// Displaying unique brands as headers in the first column
foreach($uniqBrand as $brand){
  echo "<tr><td>$brand</td>";
  foreach($uniqType as $type){
    // Find the matching entry in the $shop array
    $found = false;
    foreach($shop as $item){
      if($item['brand'] === $brand && $item['type'] === $type){
        // Determine if the price matches the lowest or highest price
        $price = $item['price'];
        $class = '';
        if($price === $lowestPrice){
          $class = 'lowest';
        } elseif($price === $highestPrice){
          $class = 'highest';
        }
        echo "<td class='$class'>$price</td>";
        $found = true;
        break;
      }
    }
    // If no corresponding entry found, display a placeholder
    if(!$found){
      echo "<td>-</td>"; // Placeholder for missing data
    }
  }
  echo "</tr>";
}
echo "</table>";
?>
</body>
</html>