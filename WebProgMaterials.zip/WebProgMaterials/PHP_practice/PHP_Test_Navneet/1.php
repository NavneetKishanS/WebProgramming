<?php
    $cell_classes = [
        ['eligendi', 'deserunt', 'eligendi', 'deserunt', 'pariatur', 'pariatur', 'pariatur'],
        ['eligendi', 'deserunt', 'eligendi', 'deserunt', 'deserunt', 'deserunt', 'pariatur'],
        ['eligendi', 'eligendi', 'eligendi', 'deserunt', 'pariatur', 'pariatur', 'pariatur'],
        ['deserunt', 'deserunt', 'eligendi', 'deserunt', 'pariatur', 'deserunt', 'deserunt'],
        ['deserunt', 'deserunt', 'eligendi', 'deserunt', 'pariatur', 'pariatur', 'pariatur'],
    ];

    $row = count($cell_classes);
    $col = count($cell_classes[0]);

    $deserunt_counter = 0;
    for ($i = 0; $i < $row; $i++) {
        for ($j = 0; $j < $col; $j++) {
            if ($cell_classes[$i][$j] === "deserunt") {
                $deserunt_counter++;
            }
        }
    }    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <title>PHP TEST</title>
</head>
<body>
    <h1>PHP TEST - GROUP 5</h1>

    <h2>Task 1: Output generation from array (4 pts)</h2>

    Array dimensions: <b><?php echo "$row x $col"; ?></b>
    <br>
    Total number of <i>deserunt</i> values: <b><?php echo "$deserunt_counter"; ?></b>

    <br>
    <table>
    <?php
            for ($i = 0; $i < $row; $i++) {
                echo "<tr>";
                for ($j = 0; $j < $col; $j++) {
                    $cell_value = $cell_classes[$i][$j];
                    echo "<td class=\"$cell_value\">" . ($i + 1) . "" . ($j + 1) . "</td>";
                }
                echo "</tr>";
            }
        ?>
    </table>
</body>
</html>
