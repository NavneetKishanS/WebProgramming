<?php
$number = $_GET['number'] ?? '';
$operation = $_GET['operation'] ?? '';
$errors = [];

if ($number === '') {
   
    $errors[] = "Number is required!";
} elseif (!is_numeric($number) || intval($number) != floatval($number)) {
   
      $errors[] = "Number must be an integer!";
}

if ($operation === '') {
      $errors[] = "Operation is required!";

} elseif ($operation !== 'square' && $operation !== 'cube') {
   
     $errors[] = "Invalid operation!";
}

$result = null;
if (empty($errors)) {
    
    $result = ($operation === 'square') ? $number * $number : $number * $number * $number;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <title>PHP TEST</title>
</head>
<body>
    <h1>PHP TEST - GROUP 5</h1>

    <h2>Task 2: Form input</h2>
    <form action="2.php" method="GET" novalidate>
        <label for="i1">Number:</label>
        <input type="text" name="number" id="i1" value="<?= $number ?>">
        <br>
        <label for="i2">Operation:</label>
        <input type="text" name="operation" id="i2" value="<?= $operation ?>">
        <br>
        <button type="submit">Calculate</button>
    </form>

    <?php if (!empty($errors)): ?>
        <h3><b>Errors:</b></h3>
        <ul>
            <?php foreach ($errors as $e): ?>
                <li><?= $e ?></li>
            <?php endforeach; ?>
        </ul>
    <?php elseif ($result !== null): ?>
        <h3>Result:</h3>
        <p>The <b><?= $operation ?></b> of <b><?= $number ?></b> is <b><?= $result ?></b></p>
    <?php endif; ?>
</body>
</html>
