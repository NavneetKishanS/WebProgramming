<?php
$entries = json_decode(file_get_contents('3.json'), true);


if (isset($_GET['insert']) && $_GET['insert'] == 1) {
    $random = rand(1, 100);

    $entry = [
        'fullname' => 'Navneet Kishan Srinivasan', 
        'count' => $random,
        'id' => uniqid() 
    ];

    $entries[$entry['id']] = $entry;
    file_put_contents('3.json', json_encode($entries));
    header("Location: 3.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <title>PHP TEST</title>
</head>
<body>

    <h1>PHP TEST - GROUP 5</h1>

    <h2>Task 3: File storage (3 pts)</h2>
    
    <?php
    
    foreach ($entries as $id => $record) {
        
        echo $record['fullname'] . ': ' . $record['count'] . '<br>';
        }   
        ?>

    <br><a style="color:green; font-weight: bold;" href="3.php?insert=1">Insert my record</a>
</body>
</html>
