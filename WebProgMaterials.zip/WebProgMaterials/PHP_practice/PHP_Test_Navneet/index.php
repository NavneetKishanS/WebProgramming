<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <title>PHP TEST</title>
</head>
<body>
    <h1>PHP TEST - GROUP 5</h1>
    <h2>Navigation - no task on this page!</h2>
    <ul>
        <li><a href="1.php">Task 1: Output generation from array (4 pts)</a></li>
        <li><a href="2.php">Task 2: Form input (3 pts)</a></li>
        <li><a href="3.php">Task 3: File storage (3 pts)</a></li>
    </ul>
</body>
</html>