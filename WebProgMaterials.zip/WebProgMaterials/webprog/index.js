const h = document.querySelector('h1')
h.innerText = 'the changed text'
h.innerHTML = 'some <i>italic</i> text'
h.style.color = 'blue'
h.style.background = 'orange'

//Task to generate a list from array:

const fruits = ["apple", "banana", "coconut","dragonfruit"]
let lis = document.createElement('ul');
fruits.forEach((fruit)=>{
let lis = document.createElement('li');
lis.textContent = fruit;

});
document.querySelector('ul').innerHTML = 
fruits.map(fruit => `<li>${fruit}</li>`).join(' ')

const matrix = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
  ];
  


matrix.forEach((rowElem)=>{
    let rowElem = document.createElement('tr')
    rowElem.forEach((elem)=>{
        let elem = document.createElement('td')
    })
})

document.querySelector('table').innerHTML =
matrix.map(elem => `<td>${elem}</td>`)

//Generate an integer b/w 1 and 100. the user has ot guess the num using text field and a button.
//respond: higher, lower or correct

const randomNumber = Math.floor(Math.random() * 100) + 1;
        
const guessField = document.getElementById('guessField');
const guessSubmit = document.getElementById('guessSubmit');
const guessResult = document.getElementById('guessResult');

guessSubmit.addEventListener('enter', checkGuess);

function checkGuess() {
    const userGuess = parseInt(guessField.value);
    
    if (userGuess < 1 || userGuess > 100 || isNaN(userGuess)) {
        guessResult.textContent = 'Please enter a valid number between 1 and 100.';
        return;
    }
    
    if (userGuess === randomNumber) {
        guessResult.textContent = 'Congratulations! You got it right!';
    } else if (userGuess < randomNumber) {
        guessResult.textContent = 'Higher! Try again.';
    } else {
        guessResult.textContent = 'Lower! Try again.';
    }
}

//turn a text field's background red if there are more than 8 chars in it.