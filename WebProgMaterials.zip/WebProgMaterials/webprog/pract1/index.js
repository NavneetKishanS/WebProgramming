console.log("hello world")

for(let i=0;i<t.length;i++)console.log(t[i])

