let prev = null
const timerSpan = document.querySelector('span#timer')


function handleWindowClick(e){
    if(prev === null){
        prev = e
    } else {
        timerSpan.innerText = e.timeStamp - prev.timeStamp
    }
}

window.addEventListener('click', handleWindowClick)

const ul = document.querySelector('ul')
ul.addEventListener('click', function(e){
    if(e.target.matches('li')){
        console.log(e.target)
        e.target.style.color = 'green'
    }
})

const table = document.querySelector('table')
table.addEventListener('click', function(e){
    if(e.target.matches('td')){
        e.target.style.backgroundColor = 'yellow'
    }
})

const inp = [m, n]

for( const m of inp){
    const tr = document.createElement('tr')
    for( const n of m){
        const td = document.createElement('td')
        tr.appendChild(td)
    }
    document.querySelector('table').appendChild(tr)
}

const widthInput = document.querySelector('#n')
const heightInput = document.querySelector('#m')
const startButton = document.querySelector('button')
const paintTable = document.querySelector('#paint')

startButton.addEventListener('click',function(e){
    const n = parseInt(widthInput.value)
    const m = parseInt(heightInput.value)

    for(let j =0;j<n;j++){
        let td = document.createElement('td')
        tr.appendChild('td')
    }
})

//Task
// Task 1: Place 2 text/number inputs (N, M) and a button a page. When the button is clicked, generate a table NxM. When a cell is clicked, set the background color of the cell to black. (Recommended to set the cells to fixed size: 20x20px)
// Task 1++: Use a color picker to set the background color. (<input type="color">)
// Task 1++++: Set the background color also when the mouse is dragged with the button pressed. (Event type: mousemove + check buttons)