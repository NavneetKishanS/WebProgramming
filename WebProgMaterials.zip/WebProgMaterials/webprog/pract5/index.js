const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');
const balls = [];

function randomColor() {
    const r = Math.floor(Math.random() * 256);
    const g = Math.floor(Math.random() * 256);
    const b = Math.floor(Math.random() * 256);
    return `rgb(${r},${g},${b})`;
}

function Ball(x, y, radius, color) {
    this.x = x;
    this.y = y;
    this.radius = radius;
    this.color = color;
    this.dx = Math.random() * 4 - 2; // Random horizontal velocity between -2 and 2
    this.dy = Math.random() * 4 - 2; // Random vertical velocity between -2 and 2

    this.draw = function() {
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.fillStyle = this.color;
        ctx.fill();
        ctx.closePath();
    }

    this.update = function() {
        this.x += this.dx;
        this.y += this.dy;

        // Bounce off edges
        if (this.x - this.radius <= 0 || this.x + this.radius >= canvas.width) {
            this.dx = -this.dx;
        }
        if (this.y - this.radius <= 0 || this.y + this.radius >= canvas.height) {
            this.dy = -this.dy;
        }
    }
}

canvas.addEventListener('click', function(event) {
    const rect = canvas.getBoundingClientRect();
    const mouseX = event.clientX - rect.left;
    const mouseY = event.clientY - rect.top;
    const radius = Math.random() * 30 + 10; // Random radius between 10 and 40
    const color = randomColor();
    const ball = new Ball(mouseX, mouseY, radius, color);
    balls.push(ball);
});

function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    for (let ball of balls) {
        ball.update();
        ball.draw();
    }

    requestAnimationFrame(animate);
}

animate();