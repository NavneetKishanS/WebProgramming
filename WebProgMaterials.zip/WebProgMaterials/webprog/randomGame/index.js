const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const winningScoreInput = document.getElementById("winningScore");
const startGameButton = document.getElementById("startGame");
const redScoreDisplay = document.getElementById("redScore");
const blueScoreDisplay = document.getElementById("blueScore");

const ballRadius = 10;
const paddleWidth = 10;
const paddleHeight = 100;
const paddleSpeed = 5;
const initialBallSpeed = 3;

let ballX, ballY, ballSpeedX, ballSpeedY;
let redPaddleY, bluePaddleY;
let redScore = 0, blueScore = 0;
let winningScore = parseInt(winningScoreInput.value);
let redColorSelected = false;
let currentPlayer = 1;

function resetGame() {
    ballX = canvas.width / 2;
    ballY = canvas.height / 2;
    ballSpeedX = initialBallSpeed;
    ballSpeedY = initialBallSpeed;
    redPaddleY = canvas.height / 2 - paddleHeight / 2;
    bluePaddleY = canvas.height / 2 - paddleHeight / 2;
    currentPlayer = 1;
}

function draw() {
    // Draw the canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw the ball
    ctx.fillStyle = redColorSelected ? "red" : "blue";
    ctx.beginPath();
    ctx.arc(ballX, ballY, ballRadius, 0, Math.PI * 2);
    ctx.fill();

    // Draw red paddle
    ctx.fillStyle = "red";
    ctx.fillRect(0, redPaddleY, paddleWidth, paddleHeight);

    // Draw blue paddle
    ctx.fillStyle = "blue";
    ctx.fillRect(canvas.width - paddleWidth, bluePaddleY, paddleWidth, paddleHeight);

    // Move the ball
    ballX += ballSpeedX;
    ballY += ballSpeedY;

    // Ball collision with top and bottom walls
    if (ballY - ballRadius < 0 || ballY + ballRadius > canvas.height) {
        ballSpeedY = -ballSpeedY;
    }

    // Ball collision with paddles
    if (ballX - ballRadius < paddleWidth && ballY > redPaddleY && ballY < redPaddleY + paddleHeight) {
        ballSpeedX = -ballSpeedX;
    }

    if (ballX + ballRadius > canvas.width - paddleWidth && ballY > bluePaddleY && ballY < bluePaddleY + paddleHeight) {
        ballSpeedX = -ballSpeedX;
    }

    // Scoring
    if (ballX - ballRadius < 0) {
        blueScore++;
        if (blueScore >= winningScore) {
            alert("Blue wins!");
            resetGame();
            blueScore = 0;
            redScore = 0;
        }
        resetGame();
    } else if (ballX + ballRadius > canvas.width) {
        redScore++;
        if (redScore >= winningScore) {
            alert("Red wins!");
            resetGame();
            blueScore = 0;
            redScore = 0;
        }
        resetGame();
    }

    // Update the score display
    redScoreDisplay.textContent = redScore;
    blueScoreDisplay.textContent = blueScore;

    requestAnimationFrame(draw);
}

startGameButton.addEventListener("click", () => {
    winningScore = parseInt(winningScoreInput.value);
    resetGame();
    draw();
});

document.addEventListener("keydown", (e) => {
    if (currentPlayer === 1) {
        if (e.key === "w" && redPaddleY > 0) {
            redPaddleY -= paddleSpeed;
        }
        if (e.key === "s" && redPaddleY + paddleHeight < canvas.height) {
            redPaddleY += paddleSpeed;
        }
    } else {
        if (e.key === "ArrowUp" && bluePaddleY > 0) {
            bluePaddleY -= paddleSpeed;
        }
        if (e.key === "ArrowDown" && bluePaddleY + paddleHeight < canvas.height) {
            bluePaddleY += paddleSpeed;
        }
    }
});

document.addEventListener("keyup", (e) => {
    if (e.key === "w" || e.key === "s") {
        redPaddleY = Math.max(0, Math.min(canvas.height - paddleHeight, redPaddleY));
    }
    if (e.key === "ArrowUp" || e.key === "ArrowDown") {
        bluePaddleY = Math.max(0, Math.min(canvas.height - paddleHeight, bluePaddleY));
    }
});

resetGame();
